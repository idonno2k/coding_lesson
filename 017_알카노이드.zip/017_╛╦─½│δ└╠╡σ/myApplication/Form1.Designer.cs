﻿namespace myApplication
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.timer_Cnt = new System.Windows.Forms.Timer(this.components);
            this.timer_Bonus1 = new System.Windows.Forms.Timer(this.components);
            this.timer_Bonus3 = new System.Windows.Forms.Timer(this.components);
            this.timer_Bonus4 = new System.Windows.Forms.Timer(this.components);
            this.timer_Bonus2 = new System.Windows.Forms.Timer(this.components);
            this.btn_Start = new System.Windows.Forms.Button();
            this.btn_Dn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // timer_Cnt
            // 
            this.timer_Cnt.Interval = 1;
            this.timer_Cnt.Tick += new System.EventHandler(this.timer_Cnt_Tick);
            // 
            // timer_Bonus1
            // 
            this.timer_Bonus1.Tick += new System.EventHandler(this.timer_Bonus1_Tick);
            // 
            // timer_Bonus3
            // 
            this.timer_Bonus3.Interval = 1000;
            this.timer_Bonus3.Tick += new System.EventHandler(this.timer_Bonus3_Tick);
            // 
            // timer_Bonus4
            // 
            this.timer_Bonus4.Interval = 1000;
            this.timer_Bonus4.Tick += new System.EventHandler(this.timer_Bonus4_Tick);
            // 
            // timer_Bonus2
            // 
            this.timer_Bonus2.Interval = 250;
            this.timer_Bonus2.Tick += new System.EventHandler(this.timer_Bonus2_Tick);
            // 
            // btn_Start
            // 
            this.btn_Start.Location = new System.Drawing.Point(444, 503);
            this.btn_Start.Name = "btn_Start";
            this.btn_Start.Size = new System.Drawing.Size(120, 50);
            this.btn_Start.TabIndex = 22;
            this.btn_Start.Text = "Start";
            this.btn_Start.UseVisualStyleBackColor = true;
            this.btn_Start.Click += new System.EventHandler(this.btn_Start_Click);
            // 
            // btn_Dn
            // 
            this.btn_Dn.Location = new System.Drawing.Point(404, 692);
            this.btn_Dn.Name = "btn_Dn";
            this.btn_Dn.Size = new System.Drawing.Size(200, 25);
            this.btn_Dn.TabIndex = 23;
            this.btn_Dn.Tag = "1";
            this.btn_Dn.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1008, 729);
            this.Controls.Add(this.btn_Dn);
            this.Controls.Add(this.btn_Start);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "알카노이드";
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseClick);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Timer timer_Cnt;
        private System.Windows.Forms.Timer timer_Bonus1;
        private System.Windows.Forms.Timer timer_Bonus3;
        private System.Windows.Forms.Timer timer_Bonus4;
        private System.Windows.Forms.Timer timer_Bonus2;
        private System.Windows.Forms.Button btn_Start;
        private System.Windows.Forms.Button btn_Dn;
    }
}

