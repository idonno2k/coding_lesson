﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Media;
using System.Threading;
using System.Windows.Forms;

namespace myApplication
{
    public partial class Form1 : Form
    {
        static Random Rnd_ = new Random();
        SoundPlayer myPlay_;

        public Form1()
        {
            InitializeComponent();
            Button_Insert();
        }

        int[] Left_ = {    19, 129, 239, 349, 459, 569, 679, 789, 899,
                           19,      239, 349,      569, 679, 789, 899,
                           19, 129, 239, 349, 459, 569,      789, 899,
                           19, 129,      349, 459, 569, 679, 789, 899,
                           19, 129, 239, 349,      569, 679,      899,
                           19, 129, 239,      459, 569, 679, 789, 899,
                               129, 239, 349, 459, 569, 679,      899 };
        int[] Top_ = {     19,  19,  19,  19,  19,  19,  19,  19,  19,
                           69,       69,  69,       69,  69,  69,  69,
                          119, 119, 119, 119, 119, 119,      119, 119,
                          169, 169,      169, 169, 169, 169, 169, 169,
                          219, 219, 219, 219,      219, 219,      219,
                          269, 269, 269,      269, 269, 269, 269, 269,
                               319, 319, 319, 319, 319, 319,      319 };
        int[] Width_ = {   90,  90,  90,  90,  90,  90,  90,  90,  90,
                           90,       90, 200,       90,  90,  90,  90,
                           90,  90,  90,  90,  90,  90,       90,  90,
                           90, 200,       90,  90,  90,  90,  90,  90,
                           90,  90,  90,  90,       90, 200,       90,
                           90,  90, 200,       90,  90,  90,  90,  90,
                                90,  90,  90,  90,  90,  90,       90 };
        int[] Height_ = {  30,  80,  30,  30,  30,  30,  30,  30,  30,
                           30,       30,  30,       30,  80,  30,  30,
                           30,  30,  30,  30,  30,  30,       30,  30,
                           30,  30,       30,  80,  30,  30,  30,  30,
                           30,  30,  30,  30,       30,  30,       30,
                           80,  30,  30,       30,  30,  30,  80,  30,
                                30,  30,  30,  30,  30,  30,       30 };
        string[][] Btn_Option_ =
        {
            new string[] { "공 추가",   "", "", "", "" },
            new string[] { "길이 증가", "", "", "", "" },
            new string[] { "유도탄",    "", "", "", "" },
            new string[] { "자  석",    "", "", "", "" },
            new string[] { "기관총",    "", "", "", "" }
        };
        
        Color[] Btn_Color_ = { Color.DodgerBlue, Color.MediumSeaGreen, Color.DarkViolet, Color.MediumBlue, Color.OrangeRed };
        List<Button> Button_ = new List<Button>();
        void Button_Insert()
        {
            Button_.Clear();
            for (int i = 0; i < 54; i++)
            {
                Button Button_Copy = new Button();
                Button_Copy.Location = new Point(Left_[i], Top_[i]);
                Button_Copy.Size = new Size(Width_[i], Height_[i]);
                Button_Copy.Tag = "0";
                Button_Copy.TabStop = false;

                X1_ = Rnd_.Next(0, Btn_Option_.Length);
                Button_Copy.Text = Btn_Option_[X1_][Rnd_.Next(0, Btn_Option_[X1_].Length)];
                Button_Copy.ForeColor = Btn_Color_[X1_];
                Button_Copy.Click += btn_Click;

                //Button_Copy.Text = Btn_Option_[2][0]; // Test
                //Button_Copy.ForeColor = Btn_Color_[2];

                Controls.Add(Button_Copy);
                Button_.Add(Button_Copy);
            }
        }

        private void btn_Click(object sender, EventArgs e)
        {
            if ((sender as Button).Text == "")
            {
                (sender as Button).Text = Btn_Option_[0][0];
                (sender as Button).ForeColor = Btn_Color_[0];
            }
            else if ((sender as Button).Text == Btn_Option_[0][0])
            {
                (sender as Button).Text = Btn_Option_[1][0];
                (sender as Button).ForeColor = Btn_Color_[1];
            }
            else if ((sender as Button).Text == Btn_Option_[1][0])
            {
                (sender as Button).Text = Btn_Option_[2][0];
                (sender as Button).ForeColor = Btn_Color_[2];
            }
            else if ((sender as Button).Text == Btn_Option_[2][0])
            {
                (sender as Button).Text = Btn_Option_[3][0];
                (sender as Button).ForeColor = Btn_Color_[3];
            }
            else if ((sender as Button).Text == Btn_Option_[3][0])
            {
                (sender as Button).Text = Btn_Option_[4][0];
                (sender as Button).ForeColor = Btn_Color_[4];
            }
            else if ((sender as Button).Text == Btn_Option_[4][0])
                (sender as Button).Text = "";
        }

        class rdoTag_
        {
            public double OldX_, OldY_;
            public double Angle_;
            public int Speed_ = 10;
            public int Bonus_ = 0;
            public int Count_ = 0;
        }

        List<RadioButton> RadioButton_ = new List<RadioButton>();
        void RadioButton_Insert(double X, double Y, double Z)
        {
            RadioButton RdoCopy_ = new RadioButton();
            rdoTag_ Tag_ = new rdoTag_();
            RdoCopy_.Tag = Tag_;
            RdoCopy_.AutoSize = true;
            Tag_.OldX_ = X;
            Tag_.OldY_ = Y;
            Tag_.Angle_ = Z;
            RdoCopy_.Left = (int)X;
            RdoCopy_.Top = (int)Y;

            Controls.Add(RdoCopy_);
            RadioButton_.Add(RdoCopy_);
        }

        private void btn_Start_Click(object sender, EventArgs e)
        {
            btn_Start.Top = 800;
            RadioButton_Insert(497, 521, Rnd_.Next(0, 359));
            //RadioButton_Insert(497, 521, 271); // Test

            timer_Cnt.Enabled = true;
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                if (timer_Bonus3.Enabled == true)
                {
                    foreach (RadioButton i in Bonus3_) (i.Tag as rdoTag_).Speed_ = 10;
                    Bonus3_.Clear();
                }
                else if (timer_Bonus4.Enabled == true)
                {
                    RadioButton RdoBonus4_ = new RadioButton();
                    rdoTag_ Tag_ = new rdoTag_();
                    RdoBonus4_.Tag = Tag_;
                    RdoBonus4_.FlatStyle = FlatStyle.Flat;
                    RdoBonus4_.ForeColor = Color.OrangeRed;
                    RdoBonus4_.Checked = true;
                    RdoBonus4_.AutoSize = true;
                    Tag_.OldX_ = btn_Dn.Left + (btn_Dn.Width / 2);
                    Tag_.OldY_ = btn_Dn.Top - 13;
                    Tag_.Angle_ = 270;
                    Tag_.Bonus_ = 4;
                    RdoBonus4_.Left = (int)Tag_.OldX_;
                    RdoBonus4_.Top = (int)Tag_.OldY_;

                    Controls.Add(RdoBonus4_);
                    Bonus4_.Add(RdoBonus4_);
                }
            }
            else if (e.Button == MouseButtons.Right) Auto_ = Auto_ ? false : true;
        }

        RadioButton rdo_;
        rdoTag_ tag_;
        Button btn_;
        private void timer_Cnt_Tick(object sender, EventArgs e)
        {
            timer_Cnt.Enabled = false;

            for (int i = 0; i < Controls.Count; i++)
                if (Controls[i] is RadioButton)
                {
                    rdo_ = Controls[i] as RadioButton;
                    tag_ = Controls[i].Tag as rdoTag_;
                    if (!tag_.Bonus_.Equals(5)) Form_Cursor();
                    RadioButton_Go();
                }
        }

        bool Auto_ = true;
        int CurPointX_;
        int btnRnd_ = 0;
        int formWidth_, btnWidth_, rdoX_;
        int btn_Dn_Left_ = 404;
        void Form_Cursor()
        {
            formWidth_ = ClientSize.Width - (btn_Dn.Width / 2);
            btnWidth_ = btn_Dn.Width / 2;
            rdoX_ = (int)Math.Round(tag_.Speed_ * Math.Cos(tag_.Angle_ * Math.PI / 180.0), 0); //X = H A

            if (Auto_) CurPointX_ = (tag_.Speed_ == 0) ? btn_Dn.Left + btnWidth_ : rdo_.Left + 7 + rdoX_ + (int)Math.Round(btnWidth_ / 100.0 * btnRnd_, 1);
            else CurPointX_ = PointToClient(new Point(Cursor.Position.X, Cursor.Position.Y)).X;

            if (CurPointX_ > btnWidth_ && CurPointX_ < formWidth_) btn_Dn.Left = CurPointX_ - btnWidth_;
            else if (CurPointX_ <= btnWidth_) btn_Dn.Left = 0;
            else if (CurPointX_ >= formWidth_) btn_Dn.Left = formWidth_ - btnWidth_;

            //btn_Dn.Left = (tag_.Speed_ == 0) ? btn_Dn.Left : rdo_.Right + 50; // Test
            //if (rdo_.Top < btn_Dn.Bottom - 2 && rdo_.Bottom > btn_Dn.Top + 2)
            //{
            //    btn_Dn.Left = rdo_.Left - 50;
            //    Thread.Sleep(500);
            //}

            foreach (RadioButton i in Bonus3_)
            {
                (i.Tag as rdoTag_).OldX_ += btn_Dn.Left - btn_Dn_Left_;
                i.Location = new Point((int)Math.Round((i.Tag as rdoTag_).OldX_, 0), (int)Math.Round((i.Tag as rdoTag_).OldY_, 0));
            }
            btn_Dn_Left_ = btn_Dn.Left;
        }

        Point newPoint1_, newPoint2_, newPoint3_, newPoint4_;
        Point oldPoint1_, oldPoint2_, oldPoint3_, oldPoint4_;
        void RadioButton_Go()
        {
            oldPoint1_.X = rdo_.Left + 12;
            oldPoint1_.Y = rdo_.Top + 11;
            oldPoint2_.X = rdo_.Left + 2;
            oldPoint2_.Y = rdo_.Top + 11;
            oldPoint3_.X = rdo_.Left + 2;
            oldPoint3_.Y = rdo_.Top + 2;
            oldPoint4_.X = rdo_.Left + 12;
            oldPoint4_.Y = rdo_.Top + 2;

            newPoint3_.X = (int)Math.Round(rdo_.Left + (Math.Cos(tag_.Angle_ * Math.PI / 180.0) * tag_.Speed_), 0);
            newPoint3_.Y = (int)Math.Round(rdo_.Top + (Math.Sin(tag_.Angle_ * Math.PI / 180.0) * tag_.Speed_), 0);
            newPoint4_.X = newPoint3_.X + 14;
            newPoint4_.Y = newPoint3_.Y;
            newPoint1_.X = newPoint3_.X + 14;
            newPoint1_.Y = newPoint3_.Y + 13;
            newPoint2_.X = newPoint3_.X;
            newPoint2_.Y = newPoint3_.Y + 13;

            if (newPoint3_.Y <= DisplayRectangle.Top)
            {
                H1_ = DisplayRectangle.Top + 1;
                Form_Wall(ref H1_, ref tag_.OldY_);

                tag_.OldY_ = H1_;
                RadioButton_Angel(0);
            }
            else if (newPoint1_.Y >= DisplayRectangle.Bottom)
            {
                H1_ = DisplayRectangle.Bottom - 14;
                Form_Wall(ref tag_.OldY_, ref H1_);

                if (RadioButton_.Count < 2)
                {
                    //tag_.OldY_ = H1_;
                    //RadioButton_Angel(0); // Test

                    RadioButton_death();
                    return;
                }
                else
                {
                    RadioButton_.Remove(rdo_);
                    Controls.Remove(rdo_);
                }
            }
            else if (newPoint3_.X <= DisplayRectangle.Left)
            {
                H1_ = DisplayRectangle.Left + 1;
                Form_Wall(ref H1_, ref tag_.OldX_);

                tag_.OldX_ = H1_;
                RadioButton_Angel(180);
            }
            else if (newPoint1_.X >= DisplayRectangle.Right)
            {
                H1_ = DisplayRectangle.Right - 15;
                Form_Wall(ref tag_.OldX_, ref H1_);

                tag_.OldX_ = H1_;
                RadioButton_Angel(180);
            }
            else Button_Go();

            if (Button_.Count < 1) Form_Clear();
            else timer_Cnt.Enabled = true;
        }

        void Form_Wall(ref double i, ref double j)
        {
            while (i <= j)
            {
                tag_.OldX_ += Math.Cos(tag_.Angle_ * Math.PI / 180.0);
                tag_.OldY_ += Math.Sin(tag_.Angle_ * Math.PI / 180.0);
            }
        }

        void Button_Go()
        {
            if (tag_.Angle_ < 90)
            {
                newPoint2_.X++; newPoint2_.Y--;
                newPoint4_.X--; newPoint4_.Y++;
                if (GetChildAtPoint(oldPoint1_) is Button) RadioButton_Enter(GetChildAtPoint(oldPoint1_) as Button);
                else if (GetChildAtPoint(oldPoint2_) is Button) RadioButton_Enter(GetChildAtPoint(oldPoint2_) as Button);
                else if (GetChildAtPoint(oldPoint4_) is Button) RadioButton_Enter(GetChildAtPoint(oldPoint4_) as Button);
                else if (GetChildAtPoint(newPoint1_) is Button) RadioButton_Hit(GetChildAtPoint(newPoint1_) as Button, 14, 13);
                else if (GetChildAtPoint(newPoint2_) is Button) RadioButton_Hit(GetChildAtPoint(newPoint2_) as Button, 1, 12);
                else if (GetChildAtPoint(newPoint4_) is Button) RadioButton_Hit(GetChildAtPoint(newPoint4_) as Button, 13, 1);
                else Button_Go_Move(tag_.Speed_);
            }
            else if (tag_.Angle_ < 180)
            {
                newPoint1_.X--; newPoint1_.Y--;
                newPoint3_.X++; newPoint3_.Y++;
                if (GetChildAtPoint(oldPoint2_) is Button) RadioButton_Enter(GetChildAtPoint(oldPoint2_) as Button);
                else if (GetChildAtPoint(oldPoint1_) is Button) RadioButton_Enter(GetChildAtPoint(oldPoint1_) as Button);
                else if (GetChildAtPoint(oldPoint3_) is Button) RadioButton_Enter(GetChildAtPoint(oldPoint3_) as Button);
                else if (GetChildAtPoint(newPoint2_) is Button) RadioButton_Hit(GetChildAtPoint(newPoint2_) as Button, 0, 13);
                else if (GetChildAtPoint(newPoint1_) is Button) RadioButton_Hit(GetChildAtPoint(newPoint1_) as Button, 13, 12);
                else if (GetChildAtPoint(newPoint3_) is Button) RadioButton_Hit(GetChildAtPoint(newPoint3_) as Button, 1, 1);
                else Button_Go_Move(tag_.Speed_);
            }
            else if (tag_.Angle_ < 270)
            {
                newPoint4_.X--; newPoint4_.Y++;
                newPoint2_.X++; newPoint2_.Y--;
                if (GetChildAtPoint(oldPoint3_) is Button) RadioButton_Enter(GetChildAtPoint(oldPoint3_) as Button);
                else if (GetChildAtPoint(oldPoint4_) is Button) RadioButton_Enter(GetChildAtPoint(oldPoint4_) as Button);
                else if (GetChildAtPoint(oldPoint2_) is Button) RadioButton_Enter(GetChildAtPoint(oldPoint2_) as Button);
                else if (GetChildAtPoint(newPoint3_) is Button) RadioButton_Hit(GetChildAtPoint(newPoint3_) as Button, 0, 0);
                else if (GetChildAtPoint(newPoint4_) is Button) RadioButton_Hit(GetChildAtPoint(newPoint4_) as Button, 13, 1);
                else if (GetChildAtPoint(newPoint2_) is Button) RadioButton_Hit(GetChildAtPoint(newPoint2_) as Button, 1, 12);
                else Button_Go_Move(tag_.Speed_);
            }
            else
            {
                newPoint3_.X++; newPoint3_.Y++;
                newPoint1_.X--; newPoint1_.Y--;
                if (GetChildAtPoint(oldPoint4_) is Button) RadioButton_Enter(GetChildAtPoint(oldPoint4_) as Button);
                else if (GetChildAtPoint(oldPoint3_) is Button) RadioButton_Enter(GetChildAtPoint(oldPoint3_) as Button);
                else if (GetChildAtPoint(oldPoint1_) is Button) RadioButton_Enter(GetChildAtPoint(oldPoint1_) as Button);
                else if (GetChildAtPoint(newPoint4_) is Button) RadioButton_Hit(GetChildAtPoint(newPoint4_) as Button, 14, 0);
                else if (GetChildAtPoint(newPoint3_) is Button) RadioButton_Hit(GetChildAtPoint(newPoint3_) as Button, 1, 1);
                else if (GetChildAtPoint(newPoint1_) is Button) RadioButton_Hit(GetChildAtPoint(newPoint1_) as Button, 13, 12);
                else Button_Go_Move(tag_.Speed_);
            }
        }

        void Button_Go_Move(int Speed_)
        {
            tag_.OldX_ += Math.Cos(tag_.Angle_ * Math.PI / 180.0) * Speed_;
            tag_.OldY_ += Math.Sin(tag_.Angle_ * Math.PI / 180.0) * Speed_;
            rdo_.Location = new Point((int)Math.Round(tag_.OldX_, 0), (int)Math.Round(tag_.OldY_, 0));
        }

        void RadioButton_death()
        {
            timer_Bonus1.Enabled = false;
            Bonus4_Close();
            Bonus2_Close();
            Bonus3_Close();

            //myPlay_ = new SoundPlayer(string.Format(@"{0}\{1}", Environment.CurrentDirectory, "Death.wav")); //용량 제한으로 생략
            //myPlay_.Play();

            rdo_.Location = new Point((int)Math.Round(tag_.OldX_, 0), (int)Math.Round(tag_.OldY_, 0));
            Thread.Sleep(2000);

            Controls.Remove(rdo_);
            RadioButton_.Clear();
            foreach (Button i in Button_) Controls.Remove(i);

            Bonus1_Close();
            btn_Dn.Left = 404; btn_Dn_Left_ = 404;
            Button_Insert();
            btn_Start.Top = 503;
            Refresh();
        }

        Graphics Graphics_;
        void Form_Clear()
        {
            Bonus1_Close();
            Bonus4_Close();
            Bonus2_Close();
            Bonus3_Close();
            btn_Dn.Left = 404; btn_Dn_Left_ = 404;

            //myPlay_ = new SoundPlayer(string.Format(@"{0}\{1}", Environment.CurrentDirectory, "Clear.wav")); //용량 제한으로 생략
            //myPlay_.Play();

            Graphics_ = CreateGraphics();
            foreach (RadioButton i in RadioButton_) Controls.Remove(i);
            RadioButton_.Clear();

            Refresh();
            Graphics_.DrawString("C", new Font(new FontFamily("돋움"), 72),
                new LinearGradientBrush(new Point(0, 0), new Point(73, 73), Color.DodgerBlue, Color.PaleTurquoise), new Point(368, 206));
            Graphics_.DrawString("l", new Font(new FontFamily("돋움"), 72),
                new LinearGradientBrush(new Point(0, 0), new Point(63, 63), Color.MediumSeaGreen, Color.PaleGreen), new Point(437, 206));
            Graphics_.DrawString("e", new Font(new FontFamily("돋움"), 72),
                new LinearGradientBrush(new Point(0, 0), new Point(40, 40), Color.DarkViolet, Color.Plum), new Point(459, 206));
            Graphics_.DrawString("a", new Font(new FontFamily("돋움"), 72),
                new LinearGradientBrush(new Point(0, 0), new Point(63, 63), Color.Red, Color.Wheat), new Point(513, 206));
            Graphics_.DrawString("r", new Font(new FontFamily("돋움"), 72),
                new LinearGradientBrush(new Point(0, 0), new Point(68, 68), Color.Black, Color.LightGray), new Point(569, 206));
            Thread.Sleep(3000);

            Button_Insert();
            btn_Start.Top = 503;
            Refresh();

            //RadioButton_Insert(497, 521, Rnd_.Next(0, 359)); // Test
            //timer_Cnt.Enabled = true;
        }

        void RadioButton_Enter(Button btnEnt_)
        {
            btn_ = btnEnt_;
            if (btn_.Width > btn_.Height)
            {
                tag_.OldY_ = (tag_.Angle_ > 179) ? btn_.Bottom : btn_.Top - rdo_.Height;
                RadioButton_Move(0);
            }
            else
            {
                tag_.OldX_ = (tag_.Angle_ > 89 && tag_.Angle_ < 270) ? btn_.Right : btn_.Left - rdo_.Width;
                RadioButton_Move(180);
            }
        }

        Point HitPoint_ = new Point();
        double H1_, H2_;
        int X1_, Y1_;
        void RadioButton_Hit(Button btnHit_, int X_, int Y_)
        {
            btn_ = btnHit_;
            if (tag_.Angle_ > 89 && tag_.Angle_ < 270) HitPoint_.X = btn_.Right - rdo_.Left;
            else HitPoint_.X = btn_.Left - rdo_.Right;
            if (tag_.Angle_ < 180) HitPoint_.Y = btn_.Top - rdo_.Bottom;
            else HitPoint_.Y = btn_.Bottom - rdo_.Top;

            H1_ = HitPoint_.Y / Math.Sin(tag_.Angle_ * Math.PI / 180.0) + 0.01; //H = Y A
            H2_ = HitPoint_.X / Math.Cos(tag_.Angle_ * Math.PI / 180.0) + 0.01; //H = X A
            X1_ = (int)Math.Round((rdo_.Left + X_) + HitPoint_.Y / Math.Tan(tag_.Angle_ * Math.PI / 180.0), 0); //X = Y A
            Y1_ = (int)Math.Round((rdo_.Top + Y_) + HitPoint_.X * Math.Tan(tag_.Angle_ * Math.PI / 180.0), 0);  //Y = X A

            if (btn_.Left <= X1_ && X1_ <= btn_.Right)
            {
                tag_.OldX_ = rdo_.Left + Math.Cos(tag_.Angle_ * Math.PI / 180.0) * H1_;
                tag_.OldY_ = rdo_.Top + Math.Sin(tag_.Angle_ * Math.PI / 180.0) * H1_;

                RadioButton_Move(0);
            }
            else if (btn_.Top <= Y1_ && Y1_ <= btn_.Bottom)
            {
                tag_.OldX_ = rdo_.Left + Math.Cos(tag_.Angle_ * Math.PI / 180.0) * H2_;
                tag_.OldY_ = rdo_.Top + Math.Sin(tag_.Angle_ * Math.PI / 180.0) * H2_;

                RadioButton_Move(180);
            }
            else Button_Go_Move(1);
        }

        void RadioButton_Move(int i)
        {
            RadioButton_Angel(i);

            if (btn_.Tag.Equals("0"))
            {
                btnRnd_ = Rnd_.Next(-100, 101);
                Game_Bonus();
                Button_.Remove(btn_);
                Controls.Remove(btn_);
            }
            else if (btn_.Tag.Equals("1") && tag_.Angle_ > 179)
            {
                tag_.Angle_ += ((tag_.OldX_ + 7) - (btn_.Left + (btn_.Width / 2))) / 5;
                if (tag_.Angle_ < 185) tag_.Angle_ = 185;
                else if (tag_.Angle_ > 355) tag_.Angle_ = 355;

                if (timer_Bonus3.Enabled == true)
                {
                    tag_.Speed_ = 0;
                    Bonus3_.Add(rdo_);
                }
            }
        }

        void RadioButton_Angel(int i)
        {
            myPlay_ = new SoundPlayer(string.Format(@"{0}\{1}", Environment.CurrentDirectory, "Angel.wav"));
            myPlay_.Play();

            rdo_.Location = new Point((int)Math.Round(tag_.OldX_, 0), (int)Math.Round(tag_.OldY_, 0));
            Thread.Sleep(25);

            if (tag_.Bonus_.Equals(4))
            {
                Controls.Remove(rdo_);
                Bonus4_.Remove(rdo_);
                return;
            }

            tag_.Count_++;
            if (tag_.Count_ < 5) tag_.Angle_ = tag_.Angle_ * -1 + i;
            else
            {
                tag_.Angle_ = tag_.Angle_ * -1 + i + Rnd_.Next(-5, 6);
                tag_.Count_ = 0;
                rdo_.Checked = rdo_.Checked ? false : true;
            }
            tag_.Angle_ = tag_.Angle_ % 360;
            tag_.Angle_ = (int)((tag_.Angle_ > 0) ? tag_.Angle_ : tag_.Angle_ + 360);
        }

        List<RadioButton> Bonus3_ = new List<RadioButton>();
        List<RadioButton> Bonus4_ = new List<RadioButton>();
        void Game_Bonus()
        {
            if (btn_.Text == "") return;
            else if (btn_.Text == Btn_Option_[0][0]) //공 추가
                RadioButton_Insert(tag_.OldX_, tag_.OldY_, (tag_.Angle_ + 180) % 360);
            else if (btn_.Text == Btn_Option_[1][0]) //길이 증가
            {
                if (timer_Bonus3.Enabled == true) Bonus3_Close();
                if (timer_Bonus4.Enabled == true) Bonus4_Close();
                if (timer_Bonus2.Enabled == true) Bonus2_Close();

                btn_Dn.ForeColor = Color.MediumSeaGreen;
                btn_Dn.Width = 600;
                timer_Bonus1.Enabled = true;
            }
            else if (btn_.Text == Btn_Option_[2][0]) //유도탄
            {
                if (timer_Bonus1.Enabled == true)
                {
                    Bonus1_Close();
                    Form_Cursor();
                }
                if (timer_Bonus3.Enabled == true) Bonus3_Close();
                if (timer_Bonus4.Enabled == true) Bonus4_Close();

                btn_Dn.ForeColor = Color.DarkViolet;
                btn_Dn.Text = "5";
                Bonus2_ = 6.0;
                timer_Bonus2.Enabled = true;
            }
            else if (btn_.Text == Btn_Option_[3][0]) //자석
            {
                if (timer_Bonus1.Enabled == true)
                {
                    Bonus1_Close();
                    Form_Cursor();
                }
                if (timer_Bonus4.Enabled == true) Bonus4_Close();
                if (timer_Bonus2.Enabled == true) Bonus2_Close();

                btn_Dn.ForeColor = Color.MediumBlue;
                btn_Dn.Text = "5";
                timer_Bonus3.Enabled = true;
            }
            else if (btn_.Text == Btn_Option_[4][0]) //기관총
            {
                if (timer_Bonus1.Enabled == true)
                {
                    Bonus1_Close();
                    Form_Cursor();
                }
                if (timer_Bonus3.Enabled == true) Bonus3_Close();
                if (timer_Bonus2.Enabled == true) Bonus2_Close();

                btn_Dn.ForeColor = Color.OrangeRed;
                btn_Dn.Text = "5";
                timer_Bonus4.Enabled = true;
            }
        }

        private void timer_Bonus1_Tick(object sender, EventArgs e)
        {
            btn_Dn.Width -= 8;
            btn_Dn.Text = ((int)((btn_Dn.Width - 200.0) / 80.0 + 1)).ToString();
            Form_Cursor();

            if (btn_Dn.Width <= 200) Bonus1_Close();
        }

        double Bonus2_;
        private void timer_Bonus2_Tick(object sender, EventArgs e)
        {
            Bonus2_ = Bonus2_ - 0.25;
            if (Bonus2_ <= 1) Bonus2_Close();
            else
            {
                btn_Dn.Text = ((int)Bonus2_).ToString();
                rdoTag_ BonusTag_;
                foreach (RadioButton i in RadioButton_)
                {
                    BonusTag_ = i.Tag as rdoTag_;
                    if (BonusTag_.Angle_ < 181)
                    {
                        int Y = btn_Dn.Top - i.Bottom;
                        int X = btn_Dn.Left + (btn_Dn.Width / 2) - i.Left + (i.Width / 2);
                        BonusTag_.Angle_ = Math.Atan2(Y, X) * 180.0 / Math.PI;
                    }
                }
            }
        }

        private void timer_Bonus3_Tick(object sender, EventArgs e)
        {
            btn_Dn.Text = (Convert.ToInt32(btn_Dn.Text) - 1).ToString();
            if (Convert.ToInt32(btn_Dn.Text) <= 0) Bonus3_Close();
        }

        private void timer_Bonus4_Tick(object sender, EventArgs e)
        {
            btn_Dn.Text = (Convert.ToInt32(btn_Dn.Text) - 1).ToString();
            if (Convert.ToInt32(btn_Dn.Text) <= 0) Bonus4_Close();
        }

        void Bonus1_Close()
        {
            timer_Bonus1.Enabled = false;
            btn_Dn.Width = 200;
            btn_Dn.Text = "";
        }

        void Bonus2_Close()
        {
            timer_Bonus2.Enabled = false;
            btn_Dn.Text = "";
        }

        void Bonus3_Close()
        {
            timer_Bonus3.Enabled = false;
            btn_Dn.Text = "";
            foreach (RadioButton i in Bonus3_) (i.Tag as rdoTag_).Speed_ = 10;
            Bonus3_.Clear();
        }

        void Bonus4_Close()
        {
            timer_Bonus4.Enabled = false;
            btn_Dn.Text = "";
            foreach (RadioButton i in Bonus4_) Controls.Remove(i);
            Bonus4_.Clear();
        }
    }
}